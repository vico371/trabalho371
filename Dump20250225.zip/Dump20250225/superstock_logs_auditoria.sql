CREATE DATABASE  IF NOT EXISTS `superstock` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `superstock`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: superstock
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `logs_auditoria`
--

DROP TABLE IF EXISTS `logs_auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs_auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `acao` varchar(255) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `logs_auditoria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_auditoria`
--

LOCK TABLES `logs_auditoria` WRITE;
/*!40000 ALTER TABLE `logs_auditoria` DISABLE KEYS */;
INSERT INTO `logs_auditoria` VALUES (1,1,'Cadastrou novo produto (ID: 5)','2024-05-08 13:30:00'),(2,1,'Editou informações do usuário \"Maria\"','2024-05-08 14:15:00'),(3,2,'Gerou relatório de vendas (Abril)','2024-05-08 17:00:00'),(4,2,'Aprovou pedido de compra (ID: 123)','2024-05-08 18:30:00'),(5,3,'Deu baixa no estoque do produto \"Camiseta\"','2024-05-08 12:00:00'),(6,3,'Atualizou status do pedido (ID: 123) para \"Enviado\"','2024-05-08 19:00:00'),(7,1,'Cadastrou novo produto (ID: 5)','2024-05-08 13:30:00'),(8,1,'Editou informações do usuário \"Maria\"','2024-05-08 14:15:00'),(9,2,'Gerou relatório de vendas (Abril)','2024-05-08 17:00:00'),(10,2,'Aprovou pedido de compra (ID: 123)','2024-05-08 18:30:00'),(11,3,'Deu baixa no estoque do produto \"Camiseta\"','2024-05-08 12:00:00'),(12,3,'Atualizou status do pedido (ID: 123) para \"Enviado\"','2024-05-08 19:00:00'),(13,1,'Cadastrou novo produto (ID: 5)','2024-05-08 13:30:00'),(14,1,'Editou informações do usuário \"Maria\"','2024-05-08 14:15:00'),(15,2,'Gerou relatório de vendas (Abril)','2024-05-08 17:00:00'),(16,2,'Aprovou pedido de compra (ID: 123)','2024-05-08 18:30:00'),(17,3,'Deu baixa no estoque do produto \"Camiseta\"','2024-05-08 12:00:00'),(18,3,'Atualizou status do pedido (ID: 123) para \"Enviado\"','2024-05-08 19:00:00');
/*!40000 ALTER TABLE `logs_auditoria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-25 22:16:05
